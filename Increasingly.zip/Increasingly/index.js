window.onload=function(){
    createPreview();
    createHeader();
    createLeftDiv();
    createDescription();
    createAddon();
    createRightDiv();
}
function createPreview(){
    var preview=document.createElement('div');
    preview.setAttribute('id','preview');
    preview.setAttribute('class','hide');
    var preview1=document.createElement('img');
    preview1.setAttribute('src','images/cam_big_1.jpg');
    preview1.setAttribute('alt','Preview1');
    preview1.setAttribute('class','preview');
    // var preview2=document.createElement('img');
    // preview2.setAttribute('src','images/cam_big_1.jpg');
    // preview2.setAttribute('alt','Preview2');
    // preview2.setAttribute('class','hide');
    // preview2.classList.add('preview');
    preview.appendChild(preview1);
    // preview.appendChild(preview2);
    document.getElementsByClassName('container')[0].appendChild(preview);
}

function createHeader(){
    var header=document.createElement('div');
    header.setAttribute('id','header');
    var backButton=document.createElement('button');
    backButton.setAttribute('id','back-button');
    var bkImg= document.createElement('img');
    bkImg.setAttribute('src','images/back_button.jpg');
    bkImg.setAttribute('alt','Back');
    backButton.appendChild(bkImg);
    header.appendChild(backButton);
    document.getElementsByClassName('container')[0].appendChild(header);
}

function createLeftDiv(){
    var leftContainer=document.createElement('div')
    leftContainer.setAttribute('id','leftContainer')
    var medImg=document.createElement('div');
    medImg.setAttribute('id','med-img');
    var frontView= document.createElement('img');
    frontView.setAttribute('src','images/cam_med_1.jpg');
    frontView.setAttribute('alt','Front View');
    frontView.setAttribute('onmouseover','showPreview()');
    frontView.setAttribute('onmouseout','hidePreview()');
    var sideView= document.createElement('img');
    sideView.setAttribute('src','images/cam_med_2.jpg');
    sideView.setAttribute('alt','Side View');
    sideView.setAttribute('onmouseover','showPreview()');
    sideView.setAttribute('onmouseout','hidePreview()');
    sideView.setAttribute('class','hide');

    var smallImg=document.createElement('div');
    smallImg.setAttribute('id','smallImg');
    var button1=document.createElement('button');
    button1.setAttribute('id','btn1');
    button1.setAttribute('class','border');
    button1.setAttribute('onclick','changeImg(0)');
    var imgIcon1=document.createElement('img');
    imgIcon1.setAttribute('src','images/btnimg1.jpg');
    imgIcon1.setAttribute('alt','Front View');
    button1.appendChild(imgIcon1);

    var button2=document.createElement('button');
    button2.setAttribute('id','btn2');
    button2.setAttribute('class','no-border');
    button2.setAttribute('onclick','changeImg(1)');
    var imgIcon2=document.createElement('img');
    imgIcon2.setAttribute('src','images/btnimg2.jpg');
    imgIcon2.setAttribute('alt','Side View');
    button2.appendChild(imgIcon2);

    var button3=document.createElement('button');
    button3.setAttribute('id','btn3');
    button3.setAttribute('class','no-border');
    var imgIcon3=document.createElement('img');
    imgIcon3.setAttribute('src','images/btnimg3.jpg');
    imgIcon3.setAttribute('alt','Side View');
    button3.appendChild(imgIcon3);

    var button4=document.createElement('button');
    button4.setAttribute('id','btn4');
    button4.setAttribute('class','no-border');
    var imgIcon4=document.createElement('img');
    imgIcon4.setAttribute('src','images/btnimg4.jpg');
    imgIcon4.setAttribute('alt','Front View');
    button4.appendChild(imgIcon4);

    smallImg.appendChild(button1);
    smallImg.appendChild(button2);
    smallImg.appendChild(button3);
    smallImg.appendChild(button4);

    medImg.appendChild(frontView);
    medImg.appendChild(sideView);
    leftContainer.appendChild(medImg);
    leftContainer.appendChild(smallImg);
    document.getElementsByClassName('container')[0].appendChild(leftContainer);

}

function changeImg(Img){
    var eleList=document.getElementById("med-img").childNodes;
   
        for(var i=0;i<eleList.length;i++){
            if(i!=Img){
                document.getElementById("med-img").childNodes[i].classList.add('hide');
            }
            else{
                document.getElementById("med-img").childNodes[i].classList.remove('hide');
            }
        }
    var borderCngEle=document.getElementById("med-img").childNodes;
    for(var j=0;j<borderCngEle.length;j++){
        if(j!=Img){
            document.getElementById("smallImg").childNodes[j].classList.add('no-border');
            document.getElementById("smallImg").childNodes[j].classList.remove('border');
        }
        else{
            document.getElementById("smallImg").childNodes[j].classList.remove('no-border');
            document.getElementById("smallImg").childNodes[j].classList.add('border');
        }
    }
}
function showPreview(){
    document.getElementById('preview').classList.remove('hide');
}
function hidePreview(){
    document.getElementById('preview').classList.add('hide');
}

function createDescription(){
    var description= document.createElement('div');
    description.setAttribute('id','description');
    var proName=document.createElement('img');
    proName.setAttribute('src','images/font1.jpg');
    proName.setAttribute('alt','Product Name');
    proName.setAttribute('id','productName')
    var selectOp=document.createElement('img');
    selectOp.setAttribute('src','images/selectOption.jpg');
    selectOp.setAttribute('alt','Select Option');
    selectOp.setAttribute('id','slectOption')

    var btnDiv=document.createElement('div');
    btnDiv.setAttribute('id','btnDiv');
//Qty1
    var button1=document.createElement('button');
    button1.setAttribute('id','btnSel1');
    button1.setAttribute('onclick','selectQty(1)')
    button1.setAttribute('class','notSelected');
    var span1=document.createElement('span');
    var span2=document.createElement('span');
    span1.innerHTML='SINGLE';
    br=document.createElement('br');
    span2.innerHTML='$199.99';
    button1.appendChild(span1);
    button1.appendChild(br);
    button1.appendChild(span2);
//Qty2
    var button2=document.createElement('button');
    button2.setAttribute('id','btnSel2');
    button2.setAttribute('onclick','selectQty(2)')
    button2.setAttribute('class','notSelected');
    var span3=document.createElement('span');
    var span4=document.createElement('span');
    span3.innerHTML='2-PACK';
    br=document.createElement('br');
    span4.innerHTML='$369.99';
    button2.appendChild(span3);
    button2.appendChild(br);
    button2.appendChild(span4);
//Qty4
    var button3=document.createElement('button');
    button3.setAttribute('id','btnSel3');
    button3.setAttribute('onclick','selectQty(4)')
    button3.setAttribute('class','notSelected');
    var span5=document.createElement('span');
    var span6=document.createElement('span');
    span5.innerHTML='4-PACK';
    br=document.createElement('br');
    span6.innerHTML='$699.99';
    button3.appendChild(span5);
    button3.appendChild(br);
    button3.appendChild(span6);

    btnDiv.appendChild(button1);
    btnDiv.appendChild(button2);
    btnDiv.appendChild(button3);

    //+,- part
    var qtyDiv=document.createElement('div');
    qtyDiv.setAttribute('id','qtyDiv');
//-button
    var minusBtn=document.createElement('button');
    minusBtn.setAttribute('id','minusBtn');
    var minusImg=document.createElement('img');
    minusImg.setAttribute('src','images/minus.jpg');
    minusBtn.setAttribute('onclick','setQty(-1)')
    minusBtn.appendChild(minusImg);
    qtyDiv.appendChild(minusBtn);
//Qty show
    var qtyBtn=document.createElement('button');
    qtyBtn.setAttribute('id','qtyBtn');
    qtyBtn.innerHTML="0";
    qtyDiv.appendChild(qtyBtn);
//+button
    var plusBtn=document.createElement('button');
    plusBtn.setAttribute('id','plusBtn');
    plusBtn.setAttribute('onclick','setQty(1)')
    var plusImg=document.createElement('img');
    plusImg.setAttribute('src','images/plus.jpg');
    plusBtn.appendChild(plusImg);
    qtyDiv.appendChild(plusBtn);


    description.appendChild(proName);
    description.appendChild(selectOp);
    description.appendChild(btnDiv);
    description.appendChild(qtyDiv);
    document.getElementsByClassName('container')[0].appendChild(description);
}
function createAddon(){
    var addonDiv=document.createElement('div');
    addonDiv.setAttribute('id','addonDiv');

    var header=document.createElement('img');
    header.setAttribute('src','images/addon.jpg');
    header.setAttribute('id','addonHdr');
    addonDiv.appendChild(header);
    createFirstAddon();
    createSecondAddon();
    createThirdAddon();
}
function createFirstAddon(){
    var addonDiv=document.createElement('div');
    addonDiv.setAttribute('id','addonDiv1');

    var header=document.createElement('img');
    header.setAttribute('src','images/addon.jpg');
    header.setAttribute('id','addonHdr');
    addonDiv.appendChild(header);

    //1stAddon
    var firstAddon=document.createElement('div');
    firstAddon.setAttribute('id','firstAddon');
    var chkbox1=document.createElement('div');
    chkbox1.setAttribute('id','checkbox1');
    var ckbox1=document.createElement('input');
    ckbox1.setAttribute('onclick','addonStatus(true,addonDiv1,0)')
    ckbox1.setAttribute('type','checkbox');
    ckbox1.setAttribute('class','checkbox');
    chkbox1.appendChild(ckbox1);
    var img1= document.createElement('img');
    img1.setAttribute('src','images/addon1.jpg');
    img1.setAttribute('id','firstImg');
    var btns1Div=document.createElement('div');
    btns1Div.setAttribute('id','btns1Div');
    var btns1=document.createElement('button');
    btns1.innerHTML="Edit";
    btns1.setAttribute('onmouseover','editAddonsOver(1)');
    btns1.setAttribute('onmouseout','editAddonsOut(1)');
    btns1.setAttribute('class','editButton')
    btns1.setAttribute('id','addon1edit');
    var span=document.createElement('span');
    span.innerHTML="";
    btns1Div.appendChild(span);
    btns1Div.appendChild(btns1);
    var edit=document.createElement('div');
    edit.setAttribute('id','dropdown');
    edit.setAttribute('onmouseover','editAddonsOver(1)');
    edit.setAttribute('onmouseout','editAddonsOut(1)');
    edit.setAttribute('class','hide');
    var a1=document.createElement('a');
    a1.innerHTML="SINGLE";
    var br=document.createElement('br');
    var a2=document.createElement('a');
    a2.innerHTML="2-PACK";
    a1.setAttribute('onclick','setAddonsQty(addonDiv1,"SINGLE",0)');
    a2.setAttribute('onclick','setAddonsQty(addonDiv1,"2-PACK",0)');
    var span=document.createElement('span');
    span.innerHTML="";
    edit.appendChild(a1);
    edit.appendChild(br);
    edit.appendChild(a2);
    btns1Div.appendChild(edit);


    firstAddon.appendChild(chkbox1);
    firstAddon.appendChild(img1);
    addonDiv.appendChild(firstAddon);
    addonDiv.appendChild(btns1Div);






    document.getElementsByClassName('container')[0].appendChild(addonDiv);
}
function createSecondAddon(){
    var addonDiv=document.createElement('div');
    addonDiv.setAttribute('id','addonDiv2');

    //1stAddon
    var firstAddon=document.createElement('div');
    firstAddon.setAttribute('id','firstAddon');
    var chkbox1=document.createElement('div');
    chkbox1.setAttribute('id','checkbox1');
    var ckbox1=document.createElement('input');
    ckbox1.setAttribute('onclick','addonStatus(true,addonDiv2,1)')
    ckbox1.setAttribute('type','checkbox');
    ckbox1.setAttribute('class','checkbox');
    chkbox1.appendChild(ckbox1);
    var img1= document.createElement('img');
    img1.setAttribute('src','images/addon2.jpg');
    img1.setAttribute('id','firstImg');
    var btns1Div=document.createElement('div');
    btns1Div.setAttribute('id','btns1Div');
    var btns1=document.createElement('button');
    btns1.innerHTML="Edit";
    btns1.setAttribute('onmouseover','editAddonsOver(2)');
    btns1.setAttribute('onmouseout','editAddonsOut(2)');
    btns1.setAttribute('class','editButton')
    btns1.setAttribute('id','addon1edit');
    var span=document.createElement('span');
    span.innerHTML="";
    btns1Div.appendChild(span);
    btns1Div.appendChild(btns1);
    var edit=document.createElement('div');
    edit.setAttribute('id','dropdown');
    edit.setAttribute('onmouseover','editAddonsOver(2)');
    edit.setAttribute('onmouseout','editAddonsOut(2)');
    edit.setAttribute('class','hide');
    var a1=document.createElement('a');
    a1.innerHTML="SINGLE";
    var br=document.createElement('br');
    var a2=document.createElement('a');
    a2.innerHTML="2-PACK";
    a1.setAttribute('onclick','setAddonsQty(addonDiv2,"SINGLE",1)');
    a2.setAttribute('onclick','setAddonsQty(addonDiv2,"2-PACK",1)');
    var span=document.createElement('span');
    span.innerHTML="";
    edit.appendChild(a1);
    edit.appendChild(br);
    edit.appendChild(a2);
    btns1Div.appendChild(edit);


    firstAddon.appendChild(chkbox1);
    firstAddon.appendChild(img1);
    addonDiv.appendChild(firstAddon);
    addonDiv.appendChild(btns1Div);
    document.getElementsByClassName('container')[0].appendChild(addonDiv);
}
function createThirdAddon(){
    var addonDiv=document.createElement('div');
    addonDiv.setAttribute('id','addonDiv3');

    //1stAddon
    var firstAddon=document.createElement('div');
    firstAddon.setAttribute('id','firstAddon');
    var chkbox1=document.createElement('div');
    chkbox1.setAttribute('id','checkbox1');
    var ckbox1=document.createElement('input');
    ckbox1.setAttribute('onclick','addonStatus(true,addonDiv3,2)')
    ckbox1.setAttribute('type','checkbox');
    ckbox1.setAttribute('class','checkbox');
    chkbox1.appendChild(ckbox1);
    var img1= document.createElement('img');
    img1.setAttribute('src','images/addon3.jpg');
    img1.setAttribute('id','firstImg');
    var btns1Div=document.createElement('div');
    btns1Div.setAttribute('id','btns1Div');
    var btns1=document.createElement('button');
    btns1.innerHTML="Edit";
    btns1.setAttribute('onmouseover','editAddonsOver(3)');
    btns1.setAttribute('onmouseout','editAddonsOut(3)');
    btns1.setAttribute('class','editButton')
    btns1.setAttribute('id','addon1edit');
    var edit=document.createElement('div');
    edit.setAttribute('id','dropdown');
    edit.setAttribute('onmouseover','editAddonsOver(3)');
    edit.setAttribute('onmouseout','editAddonsOut(3)');
    edit.setAttribute('class','hide');
    var a1=document.createElement('a');
    a1.innerHTML="SINGLE";
    var br=document.createElement('br');
    var a2=document.createElement('a');
    a2.innerHTML="2-PACK";
    a1.setAttribute('onclick','setAddonsQty(addonDiv3,"SINGLE",2)');
    a2.setAttribute('onclick','setAddonsQty(addonDiv3,"2-PACK",2)');
    var span=document.createElement('span');
    span.innerHTML="";
    edit.appendChild(a1);
    edit.appendChild(br);
    edit.appendChild(a2);

    btns1Div.appendChild(span);
    btns1Div.appendChild(btns1);
    btns1Div.appendChild(edit);



    firstAddon.appendChild(chkbox1);
    firstAddon.appendChild(img1);
    addonDiv.appendChild(firstAddon);
    addonDiv.appendChild(btns1Div);






    document.getElementsByClassName('container')[0].appendChild(addonDiv);
}
function createRightDiv(){
    var rightDiv=document.createElement('div');
    rightDiv.setAttribute('id','rightDiv');

    var header=document.createElement('div');
    header.setAttribute('id','priceSum');
    var span1=document.createElement('span');
    span1.innerHTML='Price Summary';
    header.appendChild(span1);
    rightDiv.appendChild(header);

    var calc=document.createElement('div');
    calc.setAttribute('id','calculation');
    var span2=document.createElement('span');
    span2.innerHTML='Main Product';
    var span3=document.createElement('span');
    span3.setAttribute('id','pCost');
    span3.innerHTML='$0.00';
    var br=document.createElement('br');
    var span4=document.createElement('span');
    span4.innerHTML='0 Add-ons Selected';
    var span5=document.createElement('span');
    span5.innerHTML='+ $0.00';
    span5.setAttribute('id','sCost');
    calc.appendChild(span2);
    calc.appendChild(span3);
    calc.appendChild(br);
    calc.appendChild(span4);
    calc.appendChild(span5);
    rightDiv.appendChild(calc);

    var total=document.createElement('div');
    total.setAttribute('id','checkout');
    var span6=document.createElement('span');
    span6.setAttribute('id','total');
    span6.innerHTML='Total price';
    var span7=document.createElement('span');
    span7.setAttribute('id','sum');
    span7.innerHTML='$0.00';
    var br=document.createElement('br');
    var span8=document.createElement('span');
    span8.setAttribute('id','save');
    span8.innerHTML='SAVE $70.00(35%)';
    var btn=document.createElement('button');
    btn.setAttribute('id','ckbtn');
    btn.innerHTML='Add Items to Cart';

    total.appendChild(span6);
    total.appendChild(span7);
    total.appendChild(br);
    total.appendChild(span8);
    total.appendChild(btn);

    rightDiv.appendChild(total);

    document.getElementsByClassName('container')[0].appendChild(rightDiv);
}

function selectQty(qty){
    if(qty==1){
        document.getElementById('btnSel1').classList.remove('notSelected');
        document.getElementById('btnSel1').classList.add('selected');
        document.getElementById('btnSel2').classList.add('notSelected');
        document.getElementById('btnSel2').classList.remove('selected');
        document.getElementById('btnSel3').classList.add('notSelected');
        document.getElementById('btnSel3').classList.remove('selected');
        document.getElementById('qtyBtn').innerHTML=qty;
        document.getElementById('pCost').innerHTML="$199.99";
        //document.getElementById('ckbtn').innerHTML=`Add ${qty} item to Cart`;
        
    }
    else if(qty==2){
        document.getElementById('btnSel2').classList.remove('notSelected');
        document.getElementById('btnSel2').classList.add('selected');
        document.getElementById('btnSel1').classList.add('notSelected');
        document.getElementById('btnSel1').classList.remove('selected');
        document.getElementById('btnSel3').classList.add('notSelected');
        document.getElementById('btnSel3').classList.remove('selected');
        document.getElementById('qtyBtn').innerHTML=qty;
        document.getElementById('pCost').innerHTML="$369.99";
        //document.getElementById('ckbtn').innerHTML=`Add ${qty} items to Cart`;
        
    }
    else if(qty==4){
        document.getElementById('btnSel3').classList.remove('notSelected');
        document.getElementById('btnSel3').classList.add('selected');
        document.getElementById('btnSel2').classList.add('notSelected');
        document.getElementById('btnSel2').classList.remove('selected');
        document.getElementById('btnSel1').classList.add('notSelected');
        document.getElementById('btnSel1').classList.remove('selected');
        document.getElementById('qtyBtn').innerHTML=qty;
        document.getElementById('pCost').innerHTML="$699.99";
        //document.getElementById('ckbtn').innerHTML=`Add ${qty} items to Cart`;
        
    }
    calcTotal();
}
function calcTotal(){
    var pCost=document.getElementById('pCost').innerHTML;
    if(pCost.split('$')[1]==""){
        pCost=0;
    }
    else{
        pCost=parseFloat(pCost.split('$')[1]);
    }
    var sCost=document.getElementById('sCost').innerHTML;
    if(sCost.split('$')[1]==""){
        sCost=0;
    }
    else{
        sCost=parseFloat(sCost.split('$')[1]);
    }
    document.getElementById('sum').innerHTML=`$${(pCost+sCost).toFixed(2)}`;
}
function setQty(state){
    if(state==-1 && document.getElementById('qtyBtn').innerHTML!="0"){
        document.getElementById('qtyBtn').innerHTML=parseInt(document.getElementById('qtyBtn').innerHTML)-1;
    }
    else if(state==1){
        document.getElementById('qtyBtn').innerHTML=parseInt(document.getElementById('qtyBtn').innerHTML)+1;
    }
    var pCost=document.getElementById('pCost').innerHTML;
    if(pCost.split('$')[1]==""){
        pCost=0;
    }
    else{
        pCost=parseFloat(pCost.split('$')[1]);
    }
    if(document.getElementById('qtyBtn').innerHTML=="2"){
        document.getElementById('pCost').innerHTML="$369.99";
    }
    else if(document.getElementById('qtyBtn').innerHTML=="4"){
        document.getElementById('pCost').innerHTML="$699.99";
    }
    else if(document.getElementById('qtyBtn').innerHTML=="1"){
        document.getElementById('pCost').innerHTML="$199.99";
    }
    else if(state==-1){
        pCost=(pCost-199.99).toFixed(2);
        document.getElementById('pCost').innerHTML=`$${pCost}`;
    }
    else if(state==1){
        pCost=(pCost+199.99).toFixed(2);
        document.getElementById('pCost').innerHTML=`$${pCost}`;
    }

    // if( document.getElementById('qtyBtn').innerHTML=="1"){
    //     document.getElementById('ckbtn').innerHTML=`Add 1 item to Cart`;
    // }
    // else if( document.getElementById('qtyBtn').innerHTML=="0"){
    //     document.getElementById('ckbtn').innerHTML=`Add item to Cart`;
    // }
    // else{
    //     document.getElementById('ckbtn').innerHTML=`Add ${document.getElementById('qtyBtn').innerHTML} items to Cart`;
    // }
    calcTotal();
}
function addonStatus(status,id,item){
    var sCost=parseFloat(document.getElementById('sCost').innerHTML.split('$')[1]);

    
    if(item==0){
        if(document.getElementsByClassName('checkbox')[item].checked){
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])+1} Add-ons Selected`;
            document.getElementById('sCost').innerHTML=`+ $${(sCost+129.99).toFixed(2)}`;
            document.getElementById('addonDiv1').childNodes[2].childNodes[0].innerHTML="SINGLE"
            // if(!parseInt(document.getElementById('ckbtn').innerHTML.split(" ")[1])>0){
            //     document.getElementById('ckbtn').innerHTML=`Add 1 item to Cart`;
            // }
            // else{
            //     document.getElementById('ckbtn').innerHTML=`Add ${parseInt(document.getElementById('ckbtn').innerHTML.split(" ")[1])+1} item to Cart`
            // }
            
        }
        else{
            if(document.getElementById('addonDiv1').childNodes[2].childNodes[0].innerHTML=="2-PACK"){
                document.getElementById('sCost').innerHTML=`+ $${(sCost-129.99*2).toFixed(2)}`;
                document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])-2} Add-ons Selected`;
            }
            else{
                document.getElementById('sCost').innerHTML=`+ $${(sCost-129.99).toFixed(2)}`;
                document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])-1} Add-ons Selected`;
            }
             
            // document.getElementById('sCost').innerHTML=`+ $${(sCost-129.99).toFixed(2)}`;
            document.getElementById('addonDiv1').childNodes[2].childNodes[0].innerHTML=""
        }
    }
    else if(item==1){
        if(document.getElementsByClassName('checkbox')[item].checked){
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])+1} Add-ons Selected`;
            document.getElementById('sCost').innerHTML=`+ $${(sCost+49.99).toFixed(2)}`;
            document.getElementById('addonDiv2').childNodes[1].childNodes[0].innerHTML="SINGLE"
        }
        else{
            if(document.getElementById('addonDiv2').childNodes[1].childNodes[0].innerHTML=="2-PACK"){
                document.getElementById('sCost').innerHTML=`+ $${(sCost-49.99*2).toFixed(2)}`;
                document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])-2} Add-ons Selected`;
            }
            else{
                document.getElementById('sCost').innerHTML=`+ $${(sCost-49.99).toFixed(2)}`;
                document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])-1} Add-ons Selected`;
            }
            
            document.getElementById('addonDiv2').childNodes[1].childNodes[0].innerHTML="" 
        }
    }
    else if(item==2){
        if(document.getElementsByClassName('checkbox')[item].checked){
            document.getElementById('sCost').innerHTML=`+ $${(sCost+64.99).toFixed(2)}`;
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])+1} Add-ons Selected`;
            document.getElementById('addonDiv3').childNodes[1].childNodes[0].innerHTML="SINGLE"
        }
        else{
            if(document.getElementById('addonDiv3').childNodes[1].childNodes[0].innerHTML=="2-PACK"){
                document.getElementById('sCost').innerHTML=`+ $${(sCost-64.99*2).toFixed(2)}`;
                document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])-2} Add-ons Selected`;
            }
            else{
            document.getElementById('sCost').innerHTML=`+ $${(sCost-64.99).toFixed(2)}`;
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])-1} Add-ons Selected`;
            } 
            document.getElementById('addonDiv3').childNodes[1].childNodes[0].innerHTML=""
        }
    }
    calcTotal();
}
function editAddonsOver(item){
    var id=`addonDiv${item}`;
    if(item==1 && (document.getElementsByClassName('checkbox')[item-1].checked)){
        document.getElementById(id).childNodes[2].childNodes[2].classList.remove('hide');
    }
    else if(item!=1 && (document.getElementsByClassName('checkbox')[item-1].checked)){
        document.getElementById(id).childNodes[1].childNodes[2].classList.remove('hide');
    }
}
function editAddonsOut(item){
    var id=`addonDiv${item}`;
    if(item==1 && (document.getElementsByClassName('checkbox')[item-1].checked)){
        document.getElementById(id).childNodes[2].childNodes[2].classList.add('hide');
    }
    else if(item!=1 && (document.getElementsByClassName('checkbox')[item-1].checked)){
        document.getElementById(id).childNodes[1].childNodes[2].classList.add('hide');
    }
}
function setAddonsQty(id,qty,item){
    var state=false;
    if(id.id.includes('1')){
        if(id.childNodes[2].childNodes[0].innerHTML!=qty){
            id.childNodes[2].childNodes[0].innerHTML=qty;
            state=true;
        }
    }
    else {
        if(id.childNodes[1].childNodes[0].innerHTML!=qty){
            id.childNodes[1].childNodes[0].innerHTML=qty;
            state=true;
        }
    }
    if(state){
        addonState(qty,id,item);
    }
}
function addonState(qty,id,item){
    var sCost=parseFloat(document.getElementById('sCost').innerHTML.split('$')[1]);
    if(id.id.includes('1')){
        if(qty=="SINGLE" && id.childNodes[2].childNodes[0].innerHTML=="SINGLE"){
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])-1} Add-ons Selected`;
            document.getElementById('sCost').innerHTML=`+ $${(sCost-129.99).toFixed(2)}`;
        }
        else if(qty=="2-PACK" && id.childNodes[2].childNodes[0].innerHTML=="2-PACK"){
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])+1} Add-ons Selected`;
            document.getElementById('sCost').innerHTML=`+ $${(sCost+129.99).toFixed(2)}`;
        }
    }
    else if(id.id.includes('2')){
        if(qty=="SINGLE" && id.childNodes[1].childNodes[0].innerHTML=="SINGLE"){
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])-1} Add-ons Selected`;
            document.getElementById('sCost').innerHTML=`+ $${(sCost-49.99).toFixed(2)}`;
        }
        else if(qty=="2-PACK" && id.childNodes[1].childNodes[0].innerHTML=="2-PACK"){
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])+1} Add-ons Selected`;
            document.getElementById('sCost').innerHTML=`+ $${(sCost+49.99).toFixed(2)}`;
        }
    }
    else{
        if(qty=="SINGLE" && id.childNodes[1].childNodes[0].innerHTML=="SINGLE"){
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])-1} Add-ons Selected`;
            document.getElementById('sCost').innerHTML=`+ $${(sCost-64.99).toFixed(2)}`;
        }
        else if(qty=="2-PACK" && id.childNodes[1].childNodes[0].innerHTML=="2-PACK"){
            document.getElementById('calculation').childNodes[3].innerHTML=`${parseInt(document.getElementById('calculation').childNodes[3].innerHTML.split(' ')[0])+1} Add-ons Selected`;
            document.getElementById('sCost').innerHTML=`+ $${(sCost+64.99).toFixed(2)}`;
        }
    }
    calcTotal();
}
